//
//  App_FoundationApp.swift
//  App Foundation
//
//  Created by Fabio Fontana on 09/04/25.
//

import SwiftUI

@main
struct App_FoundationApp: App {
    var body: some Scene {
        WindowGroup {
            Pandavacciuolo()
        }
    }
}
