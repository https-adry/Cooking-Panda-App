//
//  App_FoundationTests.swift
//  App FoundationTests
//
//  Created by Fabio Fontana on 09/04/25.
//

import Testing
@testable import App_Foundation

struct App_FoundationTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
